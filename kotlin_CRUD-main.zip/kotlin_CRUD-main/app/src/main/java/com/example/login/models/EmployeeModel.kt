package com.example.login.models

class EmployeeModel (
    var empId : String ?= null,
    var empName : String ?= null,
    var empAge : String ?= null,
    var empSalary :  String ?= null
        )